﻿namespace Adams.SceneGraph
{
	public interface IDrawableNode : ISceneNode
	{
		void Draw();
	}
}

